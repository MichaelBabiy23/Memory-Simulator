#include "mem_sim.h"

/**
 * @brief Initializes the simulation database.
 *
 * @param exe_file_name The name of the executable file.
 * @param swap_file_name The name of the swap file.
 * @param text_size The size of the text segment.
 * @param data_size The size of the data segment.
 * @param bss_heap_stack_size The size of the BSS, heap, and stack segments.
 * @return sim_database* Pointer to the initialized simulation database.
 */
sim_database* init_system(char exe_file_name[], char swap_file_name[], int text_size, int data_size, int bss_heap_stack_size) {
    sim_database* mem_sim = (sim_database*)malloc(sizeof(sim_database));
    if (!mem_sim) {
        perror("Failed to allocate memory for sim_database");
        exit(EXIT_FAILURE);
    }

    mem_sim->program_fd = open(exe_file_name, O_RDONLY);
    if (mem_sim->program_fd < 0) {
        perror("Failed to open executable file");
        free(mem_sim);
        exit(EXIT_FAILURE);
    }

    mem_sim->swapfile_fd = open(swap_file_name, O_RDWR | O_CREAT | O_TRUNC);
    if (mem_sim->swapfile_fd < 0) {
        perror("Failed to open swap file");
        close(mem_sim->program_fd);
        free(mem_sim);
        exit(EXIT_FAILURE);
    }

    // Initialize swap file with empty pages
    char empty_page[PAGE_SIZE] = {0};
    for (int i = 0; i < SWAP_SIZE / PAGE_SIZE; i++) {
        write(mem_sim->swapfile_fd, empty_page, PAGE_SIZE);
    }

    mem_sim->text_size = text_size;
    mem_sim->data_size = data_size;
    mem_sim->bss_heap_stack_size = bss_heap_stack_size;

    memset(mem_sim->main_memory, 0, MEMORY_SIZE);

    for (int i = 0; i < NUM_OF_PAGES; i++) {
        mem_sim->page_table[i].V = 0;
        mem_sim->page_table[i].D = 0;
        mem_sim->page_table[i].P = (i < text_size / PAGE_SIZE) ? 1 : 0;
        mem_sim->page_table[i].frame_swap = -1;
    }

    return mem_sim;
}


/**
 * @brief Prints the current state of the physical memory.
 *
 * @param mem_sim The simulation database.
 */
void print_memory(sim_database* mem_sim) {
    int i;
    printf("\n Physical memory\n");
    for(i = 0; i < MEMORY_SIZE; i++) {
        printf("[%c]\n", mem_sim->main_memory[i]);
    }
}

/**
 * @brief Prints the current state of the swap file.
 *
 * @param mem_sim The simulation database.
 */
void print_swap(sim_database* mem_sim) {
    char str[PAGE_SIZE];
    int i;
    printf("\n Swap memory\n");
    lseek(mem_sim->swapfile_fd, 0, SEEK_SET); // go to the start of the file
    while(read(mem_sim->swapfile_fd, str, PAGE_SIZE) == PAGE_SIZE) {
        for(i = 0; i < PAGE_SIZE; i++) {
            printf("[%c]\t", str[i]);
        }
        printf("\n");
    }
}

/**
 * @brief Prints the current state of the page table.
 *
 * @param mem_sim The simulation database.
 */
void print_page_table(sim_database* mem_sim) {
    int i;
    printf("\n page table \n");
    printf("Valid\t Dirty\t Permission \t Frame_swap\n");
    for(i = 0; i < NUM_OF_PAGES; i++) {
        printf("[%d]\t[%d]\t[%d]\t[%d]\n", mem_sim->page_table[i].V,
               mem_sim->page_table[i].D,
               mem_sim->page_table[i].P, mem_sim->page_table[i].frame_swap);
    }
}

/**
 * @brief Clears the system, freeing resources and closing files.
 *
 * @param mem_sim The simulation database.
 */
void clear_system(sim_database* mem_sim) {
    close(mem_sim->program_fd);
    close(mem_sim->swapfile_fd);
    free(mem_sim);
}
