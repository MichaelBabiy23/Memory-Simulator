#!/bin/bash
#323073734

gcc -Wall main.c mem_sim.c -o Ex4

./Ex4